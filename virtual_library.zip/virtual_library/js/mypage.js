document.addEventListener("DOMContentLoaded", function () {
    console.log("mypage.js loaded"); // Log to confirm the script is loaded
    window.onerror = function(message, source, lineno, colno, error) {
        console.error("Error occurred: " + message + " at " + source + ":" + lineno + ":" + colno);
    };
    
    document.getElementById("uploadForm").addEventListener("submit", function (e) {
        console.log("Form submission event captured"); // Log to confirm the event is captured
        e.preventDefault(); // Prevent form submission
        
        // Get form data
        const title = document.getElementById("title").value.trim();
        const genre = document.getElementById("genre").value.trim();
        const status = document.querySelector('input[name="status"]:checked') ? document.querySelector('input[name="status"]:checked').value : '';
        const yearPublished = document.getElementById("year_published").value.trim();
        const isbn = document.getElementById("isbn").value.trim();
        const pageCount = document.getElementById("page_count").value.trim();
        const language = document.getElementById("language").value.trim();
        const author = document.getElementById("author").value.trim();
        const publisher = document.getElementById("publisher").value.trim();
        const bookId = document.getElementById("book_id").value.trim();
        
        // Validate that all fields are filled out
        if (!title || !genre || !status || !yearPublished || !isbn || !pageCount || !language || !author || !publisher || !bookId) {
            alert("Please fill out all fields before submitting.");
            return;
        }
        
        // Prevent duplicate book entry based on ISBN
        const existingBooks = document.querySelectorAll(".book-card");
        for (let book of existingBooks) {
            if (book.querySelector("p").innerText.includes(isbn)) {
                alert("This book is already uploaded.");
                return;
            }
        }

        // Create a new book card
        const bookCard = document.createElement("div");
        bookCard.className = "book-card";
        bookCard.innerHTML = `
            <h3>Title: ${title}</h3>
            <p><strong>Genre:</strong> ${genre}</p>
            <p><strong>Status:</strong> ${status}</p>
            <p><strong>Year Published:</strong> ${yearPublished}</p>
            <p><strong>ISBN:</strong> ${isbn}</p>
            <p><strong>Pages:</strong> ${pageCount}</p>
            <p><strong>Language:</strong> ${language}</p>
            <p><strong>Author:</strong> ${author}</p>
            <p><strong>Publisher:</strong> ${publisher}</p>
            <p><strong>Book ID:</strong> ${bookId}</p>
        `;

        // Add the new book card to the book list
        document.getElementById("bookList").appendChild(bookCard);
        
        // Display success message
        const successMessage = document.createElement("div");
        successMessage.className = "upload-message";
        successMessage.innerHTML = "<p>Book uploaded successfully!</p>";
        document.querySelector(".container").insertBefore(successMessage, document.getElementById("bookList"));

        // Remove success message after a few seconds
        setTimeout(function () {
            successMessage.remove();
        }, 3000);
        
        // Clear the form
        e.target.reset();
    });
}); // Close the DOMContentLoaded event listener
