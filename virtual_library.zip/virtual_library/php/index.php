<!DOCTYPE html>
<html lang="en">
<head>
    <title>Home</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="../css/style.css"> <!-- Link to your CSS -->
</head>
<body>
    <!-- Navigation Bar -->
    <div class="topnav">
        <a href="../php/index.php">Home</a>
        <a href="../html/owner.html">My Page</a>
        <a href="../html/about.html">About</a>
    </div>

    <!-- Background Image -->
    <div class="bg"></div>
<br>
    <!-- Main Content -->
    <div class="container">
        <!-- Display Books -->
        <?php
        // PHP array simulating book data (in a real app, this data would come from a database)
        $books = [
            ['title' => 'The Silent Patient', 'author' => 'Alex Michaelides', 'genre' => 'Thriller', 'year_published' => '2019', 'isbn' => '9781250301697', 'page_count' => '336', 'language' => 'English', 'publisher' => 'Celadon Books', 'status' => 'available', 'book_id' => '1'],
            ['title' => 'Where the Crawdads Sing', 'author' => 'Delia Owens', 'genre' => 'Mystery', 'year_published' => '2018', 'isbn' => '9780735219090', 'page_count' => '384', 'language' => 'English', 'publisher' => 'G.P. Putnam\'s Sons', 'status' => 'borrowed', 'book_id' => '2'],
            ['title' => 'The Alchemist', 'author' => 'Paulo Coelho', 'genre' => 'Adventure', 'year_published' => '1988', 'isbn' => '9780062315007', 'page_count' => '208', 'language' => 'English', 'publisher' => 'HarperOne', 'status' => 'available', 'book_id' => '3'],
            ['title' => 'Educated', 'author' => 'Tara Westover', 'genre' => 'Memoir', 'year_published' => '2018', 'isbn' => '9780399590504', 'page_count' => '334', 'language' => 'English', 'publisher' => 'Random House', 'status' => 'borrowed', 'book_id' => '4'],
            ['title' => 'The Midnight Library', 'author' => 'Matt Haig', 'genre' => 'Fantasy', 'year_published' => '2020', 'isbn' => '9780525559474', 'page_count' => '304', 'language' => 'English', 'publisher' => 'Viking', 'status' => 'available', 'book_id' => '5'],
            ['title' => 'Atomic Habits', 'author' => 'James Clear', 'genre' => 'Self-help', 'year_published' => '2018', 'isbn' => '9780735211292', 'page_count' => '320', 'language' => 'English', 'publisher' => 'Avery', 'status' => 'available', 'book_id' => '6'],
            ['title' => 'The Invisible Man', 'author' => 'H.G. Wells', 'genre' => 'Science Fiction', 'year_published' => '1897', 'isbn' => '9780451531438', 'page_count' => '248', 'language' => 'English', 'publisher' => 'Signet Classics', 'status' => 'borrowed', 'book_id' => '7'],
            ['title' => 'The Great Gatsby', 'author' => 'F. Scott Fitzgerald', 'genre' => 'Classics', 'year_published' => '1925', 'isbn' => '9780743273565', 'page_count' => '180', 'language' => 'English', 'publisher' => 'Scribner', 'status' => 'available', 'book_id' => '8'],
            ['title' => 'Circe', 'author' => 'Madeline Miller', 'genre' => 'Fantasy', 'year_published' => '2018', 'isbn' => '9780316556347', 'page_count' => '400', 'language' => 'English', 'publisher' => 'Little, Brown and Company', 'status' => 'borrowed', 'book_id' => '9'],
            ['title' => 'Sapiens: A Brief History of Humankind', 'author' => 'Yuval Noah Harari', 'genre' => 'Non-fiction', 'year_published' => '2011', 'isbn' => '9780062316110', 'page_count' => '443', 'language' => 'English', 'publisher' => 'Harper', 'status' => 'available', 'book_id' => '10']
        ];

        foreach ($books as $book) {
            echo '<div class="card">';
            echo '<h3>' . htmlspecialchars($book['title']) . '</h3>';
            echo '<p>Author: ' . htmlspecialchars($book['author']) . '</p>';
            echo '<p>Genre: ' . htmlspecialchars($book['genre']) . '</p>';
            echo '<p>Year Published: ' . htmlspecialchars($book['year_published']) . '</p>';
            echo '<p>ISBN: ' . htmlspecialchars($book['isbn']) . '</p>';
            echo '<p>Pages: ' . htmlspecialchars($book['page_count']) . '</p>';
            echo '<p>Language: ' . htmlspecialchars($book['language']) . '</p>';
            echo '<p>Publisher: ' . htmlspecialchars($book['publisher']) . '</p>';
            echo '<p>Status: ' . htmlspecialchars($book['status']) . '</p>';
            echo '<p>Book ID: ' . htmlspecialchars($book['book_id']) . '</p>';
            if ($book['status'] == 'available') {
                echo '<button class="borrow-button">Borrow</button>';
            } else {
                echo '<button class="return-button">Return</button>';
            }
            echo '</div>';
        }
        ?>
    </div>

    <!-- Include JavaScript -->
    <script src="borrow.js"></script>
</body>
</html>
