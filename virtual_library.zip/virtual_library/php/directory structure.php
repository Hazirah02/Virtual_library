htdocs/
└── virtual_library/
    ├── backend/
    │   ├── db.php
    │   └── functions.php
    ├── css/
    │   └── style.css
    ├── registration_login/
    │   ├── register.php
    │   └── login.php
    ├── dashboard_Catalog/
    │   ├── dashboard.php
    │   └── add_book.php
    ├── owner-borrowing/
    │   ├── owner.php
    │   └── update_status.php
    │    
    ├── includes/
    │   ├── navbar.php
    │   └── header.php
    ├── uploads/
    │   └──background_pic.PNG
    └── index.php
