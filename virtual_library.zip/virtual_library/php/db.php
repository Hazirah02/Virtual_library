<?php
$host = 'localhost';
$dbname = 'virtual_libraryk';  // Replace with your actual database name
$user = 'root';               // XAMPP default username is 'root'
$pass = '';                   // XAMPP default password is empty

try {
    // Establish a connection to the MySQL database using PDO
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    // Handle any connection error
    echo "Database connection failed: " . $e->getMessage();
    exit();
}
?>
