<nav>
    <ul>
        <li><a href="../Dashboard_Catalog/dashboard.php">Home</a></li>
        <li><a href="../registration_login/logout.php">Logout</a></li> <!-- Logout button -->
    </ul>
</nav>
