<?php
include 'data_storage.php';

function getBooksByGenre($genre) {
    $books = getData(); // Retrieve all books from the file
    return array_filter($books, function($book) use ($genre) {
        return $book['genre'] === $genre; // Filter by genre
    });
}

// Function to get a specific user's books
function getUserBooks($owner_id) {
    $books = getData(); // Retrieve all books from the file
    return array_filter($books, function($book) use ($owner_id) {
        return $book['owner_id'] == $owner_id; // Filter by owner_id
    });
}

// Function to get the details of a specific book
function getBookById($book_id) {
    $books = getData(); // Retrieve all books from the file
    foreach ($books as $book) {
        if ($book['id'] == $book_id) {
            return $book; // Return the specific book
        }
    }
    return null; // Return null if not found
}

function getAllBooks() {
    return getData(); // Retrieve all books from the file
}

function getBorrowedBooksByUser($user_id) {
    $books = getData(); // Retrieve all books from the file
    return array_filter($books, function($book) use ($user_id) {
        return $book['borrowed_by'] == $user_id; // Filter by user_id
    });
}

function returnBook($book_id) {
    $books = getData(); // Retrieve all books from the file
    foreach ($books as &$book) {
        if ($book['book_id'] == $book_id) {
            $book['status'] = 'available'; // Update the status
            saveData($books); // Save updated data back to the file
            return true; // Return success
        }
    }
    return false; // Return failure if not found
}



function usernameExists($username) {
    $users = getData('users.json'); // Assuming you have a users.json file
    foreach ($users as $user) {
        if ($user['username'] === $username) {
            return true; // Return true if username exists
        }
    }
    return false; // Return false if not found
}
?>
