<?php
// Function to save data to a JSON file
function saveData($data, $filename = 'data.json') {
    $currentData = [];
    if (file_exists($filename)) {
        $currentData = json_decode(file_get_contents($filename), true);
    }
    $currentData[] = $data; // Append new data
    file_put_contents($filename, json_encode($currentData, JSON_PRETTY_PRINT));
}

// Function to retrieve data from a JSON file
function getData($filename = 'data.json') {
    if (file_exists($filename)) {
        return json_decode(file_get_contents($filename), true);
    }
    return []; // Return empty array if file does not exist
}
